--create database SchoolSystem
--use SchoolSystem

--create Table TBL_Students(
--StudentID int IDENTITY(1,1) PRIMARY KEY,
--StudentName varchar(30),
--StudentSurName varchar(30),
--StudentClub tinyint,
--StudentGender varchar(6)
--)

--create Table TBL_Clubs(
--ClubID tinyint IDENTITY(1,1) PRIMARY KEY,
--ClubName varchar(30)
--)

--INSERT INTO TBL_Clubs (ClubName) values ('Computer'), ('Algorithm'), ('Literature'), ('Sanitary')
--INSERT INTO TBL_Students (StudentName, StudentSurName, StudentGender) values 
--('�zg�r', 'Y�ld�r�m', 'Male'),
--('Mustafa', 'Bask�c�', 'Male'),
--('Mehmet', '�eng�r', 'Male'),
--('Melisa', 'Kabuk', 'Female'),
--('Ay�e', '�z�elik', 'Female')

--create table TBL_Lectures(
--LectureID tinyint IDENTITY(1,1) PRIMARY KEY,
--LectureName varchar(30)
--)

--create Table TBL_Teachers(
--TeacherID tinyint IDENTITY(1,1) PRIMARY KEY,
--TeacherBranch tinyint,
--TeacherName varchar(50)
--)

--create Table TBL_Notes(
--NoteID int IDENTITY(1,1) PRIMARY KEY,
--LectureID tinyint,
--StudentID int,
--Exam1 tinyint,
--Exam2 tinyint,
--Exam3 tinyint,
--ProjectNote tinyint,
--Average decimal(5,2),
--Status bit
--)

--INSERT INTO TBL_Lectures (LectureName) values
--('Math'),
--('Software Design'),
--('DataBase'),
--('Algorithm'),
--('Web Programming'),
--('Machine Learning')

--INSERT INTO TBL_Teachers (TeacherName) values
--('Zeynep �zhan'),
--('Veli Y�lmaz')

--INSERT INTO TBL_Notes (LectureID, StudentID, Exam1, Exam2, Exam3, ProjectNote) values
--(1,1,65,89,56,89),
--(1,2,56,77,64,78),
--(1,3,63,82,91,100),
--(1,4,32,44,52,61),
--(1,5,63,78,51,55)

--UPDATE TBL_Notes SET Average = (Exam1 + Exam2 + Exam3 + ProjectNote) / 4

--UPDATE TBL_Notes SET Status = 1 WHERE Average >= 50
--UPDATE TBL_Notes SET Status = 0 WHERE Average <= 50

--SELECT LectureName,Exam1,Exam2,Exam3,ProjectNote,Average,Status FROM TBL_Notes 
--INNER JOIN TBL_Lectures ON TBL_Notes.LectureID=TBL_Lectures.LectureID

--SELECT        NoteID, LectureName, (StudentName + ' ' + StudentSurName) AS StudentName, Exam1, Exam2, Exam3, ProjectNote, Average, Status
--FROM            TBL_Notes 
--INNER JOIN TBL_Lectures ON TBL_Notes.LectureID=TBL_Lectures.LectureID
--INNER JOIN TBL_Students ON TBL_Notes.StudentID=TBL_Students.StudentID

SELECT TeacherID, LectureName AS Branch, TeacherName FROM TBL_Teachers INNER JOIN TBL_Lectures ON TBL_Teachers.TeacherBranch=TBL_Lectures.LectureID